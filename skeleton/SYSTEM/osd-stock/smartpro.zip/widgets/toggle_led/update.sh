value=`/usr/trimui/bin/shmvar ledswitch`
mkdir -p /tmp/trimui_osd/toggle_led/
echo $value > /tmp/trimui_osd/toggle_led/status