if [ $# -eq 0 ] ; then
    value=`/usr/trimui/bin/shmvar btswitch`
    mkdir -p /tmp/trimui_osd/toggle_bt/
    echo $value > /tmp/trimui_osd/toggle_bt/status
else
    value=`/usr/trimui/bin/shmvar btswitch`
    if [ $value -eq 1 ] ; then
        #switch�������ñ��ű�(set.sh)�ر�
        if ! [ -f /tmp/system/bluetooth_turn_off ] ; then
            #�ر�
            touch /tmp/system/bluetooth_turn_off
            mkdir -p /tmp/trimui_osd/toggle_bt/
            echo 0 > /tmp/trimui_osd/toggle_bt/status            
        else
            #�ر��У��ٴδ�
            touch /tmp/system/bluetooth_turn_on
            mkdir -p /tmp/trimui_osd/toggle_bt/
            echo 1 > /tmp/trimui_osd/toggle_bt/status
        fi

    elif [ $value -eq 0 ] ; then
        #switch�أ����ñ��ű�(set.sh)��
        if ! [ -f /tmp/system/bluetooth_turn_on ] ; then
            #��
            touch /tmp/system/bluetooth_turn_on
            mkdir -p /tmp/trimui_osd/toggle_bt/
            echo 1 > /tmp/trimui_osd/toggle_bt/status            
        else
            #���У��ٴιر�
            touch /tmp/system/bluetooth_turn_off
            mkdir -p /tmp/trimui_osd/toggle_bt/
            echo 0 > /tmp/trimui_osd/toggle_bt/status
        fi
        
    fi
fi
